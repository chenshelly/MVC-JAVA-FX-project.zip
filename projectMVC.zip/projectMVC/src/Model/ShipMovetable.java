package Model;

public interface ShipMovetable   {
	
	public Containerr getTopContainerByIndex(int xx , int yy );
	public Containerr getTopContainer() ;
	public void addContainers(Containerr container);
}
