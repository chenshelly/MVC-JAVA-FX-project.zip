package Model;

public interface Movetable {
	
	public Containerr moveContainerTo() ;

}
